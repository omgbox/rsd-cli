# GEMINI.md

## Project Overview

This project is a command-line tool named "VLC Streamer" written in Go. It provides a terminal-based user interface (TUI) for streaming torrents directly to the VLC media player. The tool takes a magnet link, communicates with a remote streaming service (`rsd.ovh`), and proxies the video stream locally for VLC to play. It displays real-time streaming status, including download speed, connected peers, and progress.

The TUI is built using the `charmbracelet/bubbletea` library, with `lipgloss` for styling and `bubbles` for components like spinners and progress bars.

## Building and Running

### Prerequisites

- Go (version 1.25.2 or later)
- VLC Media Player

### Building

To build the application, run the following command from the project root directory:

```sh
go build -o vlc-streamer main.go
```

#### Building for Windows (Static)

To build a statically linked executable for Windows, run the following command:

```sh
GOOS=windows GOARCH=amd64 go build -ldflags "-s -w" -o vlc-streamer-windows-static.exe main.go
```

**Important:** Always build for Windows static first to ensure all dependencies are correctly bundled.

### Running

To run the application, execute the compiled binary:

```sh
./vlc-streamer
```

You can also run the application without building it first:

```sh
go run main.go
```

#### API Key

The application can be run with a custom API key for the streaming service using the `-api-key` flag:

```sh
./vlc-streamer -api-key YOUR_API_KEY
```

If no API key is provided, it defaults to a hardcoded master key.

## Development Conventions

- The project follows standard Go project structure.
- It uses Go modules for dependency management (`go.mod` and `go.sum`).
- The user interface is built with the Bubble Tea framework, following its Model-View-Update (MVU) architecture.
- The code includes a local proxy to handle the stream, which is a key architectural pattern in this application.
