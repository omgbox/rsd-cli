package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"log"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
	"time"

	"context"

	"github.com/charmbracelet/bubbles/progress"
	"github.com/charmbracelet/bubbles/spinner"
	"github.com/charmbracelet/bubbles/textinput"
	tea "github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"
)

type Config struct {
	APIKey string `json:"api_key"`
}

var configFile string



const localProxyPort = "8080"

var apiKey string
var version string = "dev"
var (
	titleStyle       = lipgloss.NewStyle().Bold(true).Foreground(lipgloss.Color("62"))
	promptStyle      = lipgloss.NewStyle().Foreground(lipgloss.Color("244"))
	spinnerStyle     = lipgloss.NewStyle().Foreground(lipgloss.Color("69"))
	statusStyle      = lipgloss.NewStyle()
	errorStyle = lipgloss.NewStyle().Foreground(lipgloss.Color("226")).Bold(true)
	statusLabelStyle = lipgloss.NewStyle().Foreground(lipgloss.Color("240"))
	successStyle     = lipgloss.NewStyle().Foreground(lipgloss.Color("42")) // Green color for success messages

	// New base style for consistent padding and margins
	baseStyle = lipgloss.NewStyle().
			PaddingLeft(2).
			PaddingRight(2).
			PaddingTop(1).
			PaddingBottom(1)

	// Style for the main content box
	contentBoxStyle = lipgloss.NewStyle().
			Border(lipgloss.RoundedBorder()).
			BorderForeground(lipgloss.Color("240")).
			Padding(1, 2)
)

var (
	// Shared HTTP client for the proxy to reuse connections
	proxyClient = &http.Client{
		Transport: &http.Transport{
			MaxIdleConns:        100,
			MaxIdleConnsPerHost: 10,
			IdleConnTimeout:     90 * time.Second,
		},
	}
	// Buffer pool for I/O copying to reduce memory allocations
	bufferPool = &sync.Pool{
		New: func() interface{} {
			// Using a 128KB buffer
			b := make([]byte, 128*1024)
			return &b
		},
	}
)

// --- API Structs ---
type FileStatus struct {
	Path                string  `json:"path"`
	PercentageCompleted float64 `json:"percentageCompleted"`
}
type StatusInfo struct {
	Name                string       `json:"name"`
	PercentageCompleted float64      `json:"percentageCompleted"`
	DownloadSpeedHuman  string       `json:"downloadSpeedHuman"`
	ConnectedPeers      int          `json:"connectedPeers"`
	Files               []FileStatus `json:"files"`
}

type APIKeyStatus struct {
	IsMasterKey bool   `json:"isMasterKey"`
	ExpiresAt   string `json:"expiresAt"`
}

// --- Bubble Tea Model ---

type (
	vlcLaunchResultMsg struct{ err error; cmd *exec.Cmd }
	proxyReadyMsg      struct{}
	statusUpdateMsg    struct{ info StatusInfo }
	statusErrorMsg     struct{ err error }
	apiKeyStatusMsg    struct{ status APIKeyStatus }
	apiKeyErrorMsg     struct{ err error }
)

type model struct {

	state         string // "input", "launching", "streaming", "error", "api_key_input"

	textInput     textinput.Model

	apiKeyInput   textinput.Model

	spinner       spinner.Model

	progress      progress.Model

	status        string

	lastMagnet    string

	statusInfo    StatusInfo

	proxyReady    bool

	lastError     error

	width         int

		height        int

		apiKeyStatus  APIKeyStatus
		apiKeySet     bool
		apiKeyStatusMsg string
			proxyCtx      context.Context
			proxyCancel   context.CancelFunc
			vlcCmd        *exec.Cmd
		
	}

func initialModel() model {
	ti := textinput.New()
	ti.Placeholder = "magnet:?xt=urn:btih:..."
	ti.Focus()
	ti.CharLimit = 0
	ti.Width = 60 // Adjusted width for better centering

	s := spinner.New()
	s.Spinner = spinner.Dot
	s.Style = spinnerStyle

	p := progress.New(progress.WithDefaultGradient())
	p.Width = 60 // Adjusted width for better centering

	apiKeyInput := textinput.New()
	apiKeyInput.Placeholder = "Enter new API key..."
	apiKeyInput.Width = 60

	// Create a cancellable context for the proxy server
	ctx, cancel := context.WithCancel(context.Background())

			m := model{
				textInput:   ti,
				apiKeyInput: apiKeyInput,
				spinner:     s,
				progress:    p,
				proxyCtx:    ctx,
				proxyCancel: cancel,
			}
		if apiKey == "" {
		m.state = "api_key_input"
		m.status = "Please enter your API key to begin."
		m.apiKeyInput.Focus()
		m.apiKeySet = false
	} else {
		m.state = "input"
		m.status = "Proxy server ready. Please enter a magnet link."
		m.textInput.Focus()
		m.apiKeySet = true
	}

	return m
}

func (m model) Init() tea.Cmd {
	cmds := []tea.Cmd{textinput.Blink, m.spinner.Tick, func() tea.Msg { return startProxyServer(m.proxyCtx) }}
	if m.apiKeySet {
		cmds = append(cmds, fetchAPIKeyStatus())
	}
	return tea.Batch(cmds...)
}

func (m model) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	var cmd tea.Cmd
	var cmds []tea.Cmd

	// --- Component Updates ---
	// It's important to update components first to ensure their state is current
	// before we process any logic.
	switch m.state {
	case "input":
		m.textInput, cmd = m.textInput.Update(msg)
		cmds = append(cmds, cmd)
	case "api_key_input":
		m.apiKeyInput, cmd = m.apiKeyInput.Update(msg)
		cmds = append(cmds, cmd)
	case "launching", "validating_api_key":
		m.spinner, cmd = m.spinner.Update(msg)
		cmds = append(cmds, cmd)
	case "streaming":
		// Handle progress bar animation
		if pMsg, ok := msg.(progress.FrameMsg); ok {
			var progCmd tea.Cmd
			newProgress, progCmd := m.progress.Update(pMsg)
			m.progress = newProgress.(progress.Model)
			cmds = append(cmds, progCmd)
		}
	}

	// --- Message and State Logic ---
	switch msg := msg.(type) {
	case tea.WindowSizeMsg:
		m.width = msg.Width
		m.height = msg.Height
		m.progress.Width = msg.Width - baseStyle.GetHorizontalPadding()*2 - contentBoxStyle.GetHorizontalPadding()*2 - 4
		m.textInput.Width = msg.Width - baseStyle.GetHorizontalPadding()*2 - contentBoxStyle.GetHorizontalPadding()*2 - 4
		m.apiKeyInput.Width = msg.Width - baseStyle.GetHorizontalPadding()*2 - contentBoxStyle.GetHorizontalPadding()*2 - 4
		return m, nil

	case tea.KeyMsg:
		if msg.Type == tea.KeyCtrlC {
			// Clean up: stop proxy server and VLC
			m.proxyCancel() // Signal proxy to shut down
			if m.vlcCmd != nil && m.vlcCmd.Process != nil {
				log.Println("Terminating VLC...")
				if runtime.GOOS == "windows" {
					exec.Command("taskkill", "/F", "/IM", "vlc.exe").Run()
				} else {
					m.vlcCmd.Process.Kill()
				}
			}
			return m, tea.Quit
		} else if msg.Type == tea.KeyEsc && m.state != "api_key_input" {
			return m, tea.Quit
		}

		// State-specific key handling
		switch m.state {
		case "input":
			if msg.String() == "k" && m.textInput.Value() == "k" {
				m.state = "api_key_input"
				m.status = "Enter new API Key."
				m.textInput.Reset()
				m.textInput.Blur()
				m.apiKeyInput.Focus()
				cmds = append(cmds, textinput.Blink)
			} else if msg.Type == tea.KeyEnter && m.proxyReady {
				if !m.apiKeySet {
					m.status = "Cannot stream: API key is not valid or not set."
				} else {
					magnetLink := m.textInput.Value()
					if magnetLink != "" {
						if err := validateMagnetLink(magnetLink); err != nil {
							m.status = errorStyle.Render(fmt.Sprintf("Invalid magnet link: %v", err))
						} else {
							m.state = "launching"
							m.status = "Launching VLC..."
							m.lastMagnet = magnetLink
							m.textInput.Reset()
							cmds = append(cmds, launchVLC(magnetLink))
						}
					}
				}
			}
		case "api_key_input":
			if msg.Type == tea.KeyEnter {
				newApiKey := m.apiKeyInput.Value()
				if newApiKey == "" {
					m.status = "API key cannot be empty. Please enter a valid key."
				} else {
					apiKey = newApiKey
					m.state = "validating_api_key"
					m.status = "Validating API key..."
					m.apiKeyInput.Blur()
					cmds = append(cmds, fetchAPIKeyStatus())
				}
			} else if msg.Type == tea.KeyEsc {
				if m.apiKeySet {
					m.state = "input"
					m.status = "API key change cancelled."
					m.apiKeyInput.Reset()
					m.apiKeyInput.Blur()
					m.textInput.Focus()
					cmds = append(cmds, tea.Batch(textinput.Blink, fetchAPIKeyStatus()))
				}
			}
		case "streaming", "error":
			if msg.String() == "n" {
				if m.lastError != nil && strings.Contains(m.lastError.Error(), "401 Unauthorized") {
					m.state = "api_key_input"
					m.status = "Your API key is unauthorized. Please enter a new API Key."
					m.apiKeyInput.Focus()
					cmds = append(cmds, textinput.Blink)
				} else {
					m.state = "input"
					m.status = "Please enter a magnet link."
					m.statusInfo = StatusInfo{}
					m.lastError = nil
					m.textInput.Focus()
					cmds = append(cmds, textinput.Blink)
				}
			} else if msg.String() == "k" {
				m.state = "api_key_input"
				m.status = "Enter new API Key."
				m.textInput.Reset()
				m.textInput.Blur()
				m.apiKeyInput.Focus()
				cmds = append(cmds, textinput.Blink)
			}
		}
	
	// Other message types
	case proxyReadyMsg:
		m.proxyReady = true
		if m.state == "input" {
			m.status = "Proxy server ready. Please enter a magnet link."
			if m.apiKeySet {
				cmds = append(cmds, fetchAPIKeyStatus())
			}
		}
	case vlcLaunchResultMsg:
		m.vlcCmd = msg.cmd // Store the VLC command for later termination
		if msg.err != nil {
			m.state = "error"
			m.lastError = msg.err
		} else {
			m.state = "streaming"
			m.status = "VLC launched. Fetching stream status..."
			cmds = append(cmds, fetchStatus(m.lastMagnet))
		}
	case statusUpdateMsg:
		m.statusInfo = msg.info
		progCmd := m.progress.SetPercent(m.statusInfo.PercentageCompleted / 100)
		cmds = append(cmds, progCmd)
		cmds = append(cmds, tea.Tick(2*time.Second, func(t time.Time) tea.Msg {
			return fetchStatus(m.lastMagnet)()
		}))
	case statusErrorMsg:
		if strings.Contains(msg.err.Error(), "401") {
			m.lastError = msg.err
m.state = "error"
		} else {
			m.status = fmt.Sprintf("Error fetching status: %v. Retrying...", msg.err)
			cmds = append(cmds, tea.Tick(5*time.Second, func(t time.Time) tea.Msg {
				return fetchStatus(m.lastMagnet)()
			}))
		}
	case apiKeyStatusMsg:
		m.apiKeyStatus = msg.status
		m.apiKeySet = false // Default to false, prove it's valid
					if m.apiKeyStatus.IsMasterKey {
						m.apiKeyStatusMsg = successStyle.Render("Using master API key unlimited")
						m.apiKeySet = true
		
		} else if m.apiKeyStatus.ExpiresAt != "" {
			expiresAt, err := time.Parse(time.RFC3339, m.apiKeyStatus.ExpiresAt)
			if err != nil {
				m.apiKeyStatusMsg = "Could not parse API key expiration date."
				m.state = "error"
				m.lastError = err
			} else {
				daysLeft := time.Until(expiresAt).Hours() / 24
				if daysLeft < 0 {
					m.apiKeyStatusMsg = errorStyle.Render(fmt.Sprintf("API Key Expired on %s", expiresAt.Format("Jan 02, 2006")))
				} else {
					m.apiKeyStatusMsg = successStyle.Render(fmt.Sprintf("API Key expires on %s (%.0f days left)", expiresAt.Format("Jan 02, 2006"), daysLeft))
					m.apiKeySet = true
				}
			}
		}

		if m.state == "validating_api_key" {
			if m.apiKeySet {
				m.state = "input"
				m.status = "Please enter a magnet link."
				saveConfig()
				m.textInput.Focus()
				cmds = append(cmds, textinput.Blink)
			} else {
				m.state = "api_key_input"
				m.status = "Invalid or expired API key. Please try again."
				m.apiKeyInput.Focus()
				cmds = append(cmds, textinput.Blink)
			}
		} else if m.apiKeySet {
			m.status = "Please enter a magnet link."
		}
	case apiKeyErrorMsg:
		if m.state == "validating_api_key" {
			m.state = "api_key_input"
			m.status = errorStyle.Render(fmt.Sprintf("API key is invalid: %v. Please try again.", msg.err))
			m.apiKeyInput.Focus()
			cmds = append(cmds, textinput.Blink)
		} else {
			m.state = "error"
			m.lastError = msg.err
		}
	}

	return m, tea.Batch(cmds...)
}




func (m model) View() string {
	var content string

	switch m.state {
	case "input":
		content = viewInput(m)
	case "api_key_input":
		content = viewApiKeyInput(m)
	case "validating_api_key":
		content = viewLaunching(m) // Re-use the launching view for the spinner
	case "launching":
		content = viewLaunching(m)
	case "streaming":
		content = viewStreaming(m)
	case "error":
		content = viewError(m)
	}

	// Header
	header := titleStyle.Render(fmt.Sprintf("VLC Streamer Proxy (v%s)", version))
	fullContent := lipgloss.JoinVertical(lipgloss.Left, header, "", content)

	// Apply base style and wrap in a content box
	styledContent := baseStyle.Render(fullContent)
	boxedContent := contentBoxStyle.Render(styledContent)

	// Center the final output
	return lipgloss.Place(
		m.width,
		m.height,
		lipgloss.Center,
		lipgloss.Center,
		boxedContent,
	)
}

func viewInput(m model) string {
	var content []string
	if m.apiKeySet && m.apiKeyStatusMsg != "" {
		content = append(content, statusStyle.Render(m.apiKeyStatusMsg))
	}
	content = append(content, promptStyle.Render(m.status))
	content = append(content, m.textInput.View())
	content = append(content, promptStyle.Render("(Ctrl+C or Esc to quit | Press 'k' for New API Key)"))
	content = append(content, promptStyle.Render(fmt.Sprintf("API Key config file: %s", configFile)))

	return lipgloss.JoinVertical(lipgloss.Left, content...)
}

func viewApiKeyInput(m model) string {
	var content []string
	content = append(content, promptStyle.Render(m.status))
	content = append(content, m.apiKeyInput.View())
	if m.apiKeySet {
		content = append(content, promptStyle.Render("(Enter to save, Esc to cancel)"))
	} else {
		content = append(content, promptStyle.Render("(Enter to save)"))
	}
	return lipgloss.JoinVertical(lipgloss.Left, content...)
}

func viewLaunching(m model) string {
	return fmt.Sprintf("%s %s", m.spinner.View(), m.status)
}

func viewStreaming(m model) string {
	statusLines := []string{
		m.progress.View(),
		"",
		statusStyle.Render(statusLabelStyle.Render("Torrent: ") + m.statusInfo.Name),
		statusStyle.Render(statusLabelStyle.Render("Peers: ") + fmt.Sprintf("%d", m.statusInfo.ConnectedPeers)),
		statusStyle.Render(statusLabelStyle.Render("Speed: ") + m.statusInfo.DownloadSpeedHuman),
		statusStyle.Render(statusLabelStyle.Render("Downloaded: ") + fmt.Sprintf("%.2f%%", m.statusInfo.PercentageCompleted)),
		"",
		promptStyle.Render("(Press 'n' for a new magnet link)"),
	}
	return lipgloss.JoinVertical(lipgloss.Left, statusLines...)
}

func viewError(m model) string {
	var content []string
	content = append(content, errorStyle.Render(fmt.Sprintf("An error occurred: %v", m.lastError)))
	content = append(content, promptStyle.Render("(Press 'n' to try again | Press 'k' for New API Key)"))
	return lipgloss.JoinVertical(lipgloss.Left, content...)
}


func loadConfig() {
	if configFile == "" {
		return
	}
	data, err := os.ReadFile(configFile)
	if err != nil {
		return
	}
	var config Config
	if err := json.Unmarshal(data, &config); err == nil {
		if config.APIKey != "" {
			apiKey = config.APIKey
		}
	}
}

func saveConfig() {
	if configFile == "" {
		return
	}
	config := Config{APIKey: apiKey}
	data, err := json.MarshalIndent(config, "", "  ")
	if err != nil {
		return
	}
	os.MkdirAll(filepath.Dir(configFile), 0755)
	os.WriteFile(configFile, data, 0644)
}

// --- Commands and Logic ---

func validateMagnetLink(s string) error {
	if s == "" {
		return nil // Allow empty input, validation happens on enter
	}
	if !strings.HasPrefix(s, "magnet:?xt=urn:btih:") {
		return fmt.Errorf("invalid magnet link format")
	}
	return nil
}

func findVLC() string {
	// Common VLC installation paths on Windows
	commonPaths := []string{
		"C:\\Program Files\\VideoLAN\\VLC\\vlc.exe",
		"C:\\Program Files (x86)\\VideoLAN\\VLC\\vlc.exe",
	}

	// Check if vlc is in PATH
	if p, err := exec.LookPath("vlc"); err == nil {
		return p
	}

	// Check common installation paths
	for _, path := range commonPaths {
		if _, err := os.Stat(path); err == nil {
			return path
		}
	}
	return "" // VLC not found
}

func fetchAPIKeyStatus() tea.Cmd {
	return func() tea.Msg {
		statusURL := "https://rsd.ovh/user/api-key-status"
		req, err := http.NewRequest("GET", statusURL, nil)
		if err != nil {
			return apiKeyErrorMsg{err}
		}
		req.Header.Set("X-API-Key", apiKey)

		resp, err := proxyClient.Do(req)
		if err != nil {
			return apiKeyErrorMsg{err}
		}
		defer resp.Body.Close()

		if resp.StatusCode != http.StatusOK {
			return apiKeyErrorMsg{fmt.Errorf("API returned status: %s", resp.Status)}
		}

		var status APIKeyStatus
		if err := json.NewDecoder(resp.Body).Decode(&status); err != nil {
			return apiKeyErrorMsg{err}
		}
		return apiKeyStatusMsg{status: status}
	}
}

func fetchStatus(magnetLink string) tea.Cmd {
	return func() tea.Msg {
		statusURL := fmt.Sprintf("https://rsd.ovh/status?url=%s", url.QueryEscape(magnetLink))
		req, err := http.NewRequest("GET", statusURL, nil)
		if err != nil {
			return statusErrorMsg{err}
		}
		req.Header.Set("X-API-Key", apiKey)

		resp, err := proxyClient.Do(req) // Use the custom client
		if err != nil {
			return statusErrorMsg{err}
		}
		defer resp.Body.Close()

		if resp.StatusCode != http.StatusOK {
			return statusErrorMsg{fmt.Errorf("API returned status: %s", resp.Status)}
		}

		var statusInfo StatusInfo
		if err := json.NewDecoder(resp.Body).Decode(&statusInfo); err != nil {
			return statusErrorMsg{err}
		}
		return statusUpdateMsg{info: statusInfo}
	}
}

func launchVLC(magnetLink string) tea.Cmd {
	return func() tea.Msg {
		if runtime.GOOS == "windows" {
			exec.Command("taskkill", "/F", "/IM", "vlc.exe").Run()
		}
		localStreamURL := fmt.Sprintf("http://localhost:%s/stream?url=%s", localProxyPort, url.QueryEscape(magnetLink))
		var cmd *exec.Cmd
		if runtime.GOOS == "windows" {
			vlcPath := findVLC()
			if vlcPath == "" {
				return vlcLaunchResultMsg{err: fmt.Errorf("VLC not found. Please ensure VLC is installed and in your PATH, or installed in a common location like C:\\Program Files\\VideoLAN\\VLC\\"), cmd: nil}
			}
			cmd = exec.Command(vlcPath, localStreamURL)
		} else {
			cmd = exec.Command("vlc", localStreamURL)
		}
		err := cmd.Start()
		return vlcLaunchResultMsg{err: err, cmd: cmd}
	}
}
func startProxyServer(ctx context.Context) tea.Msg {
	mux := http.NewServeMux()
	mux.HandleFunc("/stream", proxyHandler)

	server := &http.Server{
		Addr:    ":" + localProxyPort,
		Handler: mux,
	}

	go func() {
		<-ctx.Done() // Wait for context cancellation
		if err := server.Shutdown(context.Background()); err != nil {
			log.Printf("Proxy server shutdown error: %v", err)
		}
		log.Println("Proxy server stopped.")
	}()

	go func() {
		if err := server.ListenAndServe(); err != http.ErrServerClosed {
			log.Fatalf("Proxy server error: %v", err)
		}
	}()

	time.Sleep(100 * time.Millisecond) // Give server a moment to start
	return proxyReadyMsg{}
}

func proxyHandler(w http.ResponseWriter, r *http.Request) {
	magnetLink := r.URL.Query().Get("url")
	if magnetLink == "" {
		http.Error(w, "Missing 'url' query parameter", http.StatusBadRequest)
		return
	}
	remoteURL := fmt.Sprintf("https://rsd.ovh/stream?url=%s", magnetLink)
	req, err := http.NewRequest("GET", remoteURL, nil)
	if err != nil {
		http.Error(w, "Failed to create request", http.StatusInternalServerError)
		return
	}
	if rangeHeader := r.Header.Get("Range"); rangeHeader != "" {
		req.Header.Set("Range", rangeHeader)
	}
	req.Header.Set("X-API-Key", apiKey)
	resp, err := proxyClient.Do(req) // Use the custom client
	if err != nil {
		http.Error(w, "Failed to fetch remote URL", http.StatusBadGateway)
		return
	}
	defer resp.Body.Close()
	for key, values := range resp.Header {
		for _, value := range values {
			w.Header().Add(key, value)
		}
	}
	w.WriteHeader(resp.StatusCode)

	// Use a buffer from the pool for copying
	buf := bufferPool.Get().(*[]byte)
	defer bufferPool.Put(buf)

	_, err = io.CopyBuffer(w, resp.Body, *buf)
	if err != nil {
		if strings.Contains(err.Error(), "forcibly closed by the remote host") || strings.Contains(err.Error(), "broken pipe") {
			// This is an expected error when VLC closes the connection.
			return
		}
	}
}

func main() {
	// First, set up the config file path. This is needed for both loading and saving.
	home, err := os.UserHomeDir()
	if err == nil {
		configFile = filepath.Join(home, ".vlc-streamer", "config.json")
	}

	// Next, define and parse the command-line flag for the API key.
	flag.StringVar(&apiKey, "api-key", "", "API key for the streaming service (optional)")
	flag.Parse()

	// If the API key was not provided via a flag, try to load it from the config file.
	if apiKey == "" {
		loadConfig()
	}

	// Now, start the application.
	p := tea.NewProgram(initialModel())
	if _, err := p.Run(); err != nil {
		fmt.Printf("Alas, there's been an error: %v", err)
		os.Exit(1)
	}
}
